#pragma once 
#include "../Utilities/utilities.h" // if you use STL, please include this line AFTER all other include
#include "Globals.h"

class Camera {
protected:
	Matrix m_WorldMatrix, m_ViewMatrix, m_RotationMatrix, m_TranslationMatrix, m_ProjectionMatrix;
	Vector3 m_Position, m_Target;
	GLfloat m_Velocity = 0.01f;
	GLfloat m_AngularVelocity = 0.5f;

	Vector3 m_vUp;
	GLboolean isMoved, isRotation;

	void CalculateRotation();
	void CalculateTranslation();

public:
	Camera();
	void MoveAlongLocalX(GLfloat deltaTime);
	void MoveAlongLocalY(GLfloat deltaTime);
	void MoveAlongLocalZ(GLfloat deltaTime);

	void RotateAroundLocalX(GLfloat deltaTime);
	void RotateAroundWorldY(GLfloat deltaTime);
	void RotateAroundLocalZ(GLfloat deltaTime);

	Matrix UpdateWorldMatrix();
	Matrix UpdateViewMatrix();
	void UpdateTarget(Vector3 target);

	Matrix GetViewMatrix();
	Matrix GetProjectionMatrix();
	Matrix GetWorldMatrix();
	GLfloat* GetPosition();	
	void SetProjectionMatrix(float fov, float nearP, float farP);
	void SetProjectionMatrix(float left, float right, float bot, float top, float nearP, float farP);
	void SetSpeed(float speed);
};
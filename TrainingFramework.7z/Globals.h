#pragma once

class Globals
{
public:
	static const int screenWidth = 960;
	static const int screenHeight = 720;
};
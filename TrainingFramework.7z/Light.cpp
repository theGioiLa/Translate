#include "stdafx.h"
#include "Light.h"


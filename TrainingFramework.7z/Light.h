#pragma once
 
class Light {

};
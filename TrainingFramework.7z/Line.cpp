#include "stdafx.h"
#include "Line.h"


Line::Line()
{
}


Line::~Line()
{
}

#pragma once
#include "Object.h"
class Line :
	public Object
{
public:
	Line();
	~Line();
};


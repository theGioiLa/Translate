#include "stdafx.h"
#include "Model.h"

Model::Model(GLint id) : m_Id(id), m_pVertices(nullptr), m_pIndex(nullptr), m_nIndices(0), m_nVertices(0), m_vboId(0), m_iboId(0) {
	m_Info = new char[80];
}

int Model::Init() {
	return BindInfo();
}

void Model::Init(int x, int y, int w, int h, int textureW, int textureH, Vector2 origin) {
	m_nVertices = 4; m_nIndices = 6;
	m_pVertices = new Vertex[m_nVertices];
	m_pIndex = new int[m_nIndices];
	
	m_pIndex[0] = 0; m_pIndex[1] = 1; m_pIndex[2] = 2;
	m_pIndex[3] = 1; m_pIndex[4] = 2; m_pIndex[5] = 3;

	Vector3 delta = Vector3(origin.x - (float)w / 2, origin.y - (float)h / 2, 0.0);

	m_pVertices[0].pos = Vector3(-w / 2.0, -h / 2.0, 0.0) - delta;
	m_pVertices[1].pos = Vector3(w / 2.0, -h / 2.0, 0.0) - delta;
	m_pVertices[2].pos = Vector3(-w / 2.0, h / 2.0, 0.0) - delta;
	m_pVertices[3].pos = Vector3(w / 2.0, h / 2.0, 0.0) - delta;

	m_pVertices[0].pos = Vector3((float)x / textureW, (float)(y + h) / textureH, 0.0);
	m_pVertices[1].pos = Vector3((float)(x + w) / textureW, (float)(y + h) / textureH, 0.0);
	m_pVertices[2].pos = Vector3((float)x / textureW, (float)y / textureH, 0.0);
	m_pVertices[3].pos = Vector3((float)(x + w) / textureW, (float)y / textureH, 0.0);
}

void Model::BindData() {
	glGenBuffers(1, &m_vboId);
	glBindBuffer(GL_ARRAY_BUFFER, m_vboId);
	glBufferData(GL_ARRAY_BUFFER, sizeof(Vertex)*m_nVertices, m_pVertices, GL_STATIC_DRAW);
	glBindBuffer(GL_ARRAY_BUFFER, 0);

	glGenBuffers(1, &m_iboId);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m_iboId);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(int)*m_nIndices, m_pIndex, GL_STATIC_DRAW);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

	if (m_pVertices != nullptr) {
		delete[] m_pVertices;
		m_pVertices = nullptr;
	}

	if (m_pIndex != nullptr) {
		delete[] m_pIndex;
		m_pIndex = nullptr;
	}
}

int Model::BindInfo() {
	FILE* file;
	if (fopen_s(&file, m_Info, "r") != 0) return -1;

	fscanf_s(file, "NrVertices: %d\n", &m_nVertices);

	m_pVertices = new Vertex[m_nVertices];
	for (int i = 0; i < m_nVertices; i++) {
		fscanf_s(
			file, "%*d. pos:[%f, %f, %f]; norm:[%*f, %*f, %*f]; binorm:[%*f, %*f, %*f]; tgt:[%*f, %*f, %*f]; uv:[%f, %f];\n",
			&m_pVertices[i].pos.x,		&m_pVertices[i].pos.y,		&m_pVertices[i].pos.z,
			&m_pVertices[i].texcoord.x, &m_pVertices[i].texcoord.y
		);
	}

	fscanf_s(file, "NrIndices: %d\n", &m_nIndices);

	m_pIndex = new int[m_nIndices];
	for (int i = 0; i < m_nIndices; i += 3) {
		fscanf_s(file, "%*d.    %d, %d, %d\n", &m_pIndex[i], &m_pIndex[i + 1], &m_pIndex[i + 2]);
	}

	fclose(file);
	return 0;
}

void Model::CleanUp() {
	if (m_Info != nullptr) {
		delete[] m_Info;
		m_Info = nullptr;
	}

	if (m_vboId != -1) {
		glDeleteBuffers(1, &m_vboId);
		m_vboId = -1;
	}

	if (m_iboId != -1) {
		glDeleteBuffers(1, &m_iboId);
		m_iboId = -1;
	}
}

void Model::SetVertices(Vertex* vertices) { m_pVertices = vertices; }

#pragma once
#include "GLES2\gl2.h"
#include "../Utilities/utilities.h"
#include "Vertex.h"

class Model {
	Vertex* m_pVertices;
	int* m_pIndex;
	GLint m_Id;

public:
	unsigned int m_nIndices, m_nVertices;
	GLuint m_vboId, m_iboId;
	char* m_Info;

	Model(GLint id);	
	Model() {}

	int Init();
	void Init(int x, int y, int w, int h, int textureW, int textureH, Vector2 origin);
	void BindData();
	int BindInfo();
	void CleanUp();
	void SetVertices(Vertex* vertices);
};
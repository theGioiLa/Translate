#include "stdafx.h"
#include "Object.h"
Object::Object(GLuint id) : m_Id(id), m_Scale(Vector3(1, 1, 1)), m_RotationalAngle(Vector3(0, 0, 0)),
	m_Position(Vector3(0, 0, 0)) {
	resourceManager = ResourceManager::GetInstance();
	m_Type = new char[20];
}

Object::Object() : m_Scale(Vector3(1, 1, 1)), m_RotationalAngle(Vector3(0, 0, 0)),
	m_Position(Vector3(0, 0, 0)) {
	resourceManager = ResourceManager::GetInstance();
}

Object::~Object() {
	if (m_Type) {
		delete m_Type;
		m_Type = nullptr;
	}
}

int Object::Init() {
	GLint program = m_pShader->program;
	glEnable(m_pShader->states);

	if (m_LCubTexes.size() == 0) {
		GLint texUnit = 0;
		for (auto& tex2D : m_LTextures) {
			if (tex2D->isOn()) {
				tex2D->Init();
				tex2D->m_TexUnit = texUnit;
				texUnit++;
			}
		}
	}
	else {
		GLint texUnit = 0;
		for (auto& texCube: m_LCubTexes) {
			if (texCube->isOn()) {
				texCube->Init();
				texCube->m_TexUnit = texUnit;
				texUnit++;
			}
		}
	}

	if (m_pModel->Init() != 0) return -1;
	m_pModel->BindData();
	return 0;
}

void Object::Draw() {
	glUseProgram(m_pShader->program);
	if (m_LCubTexes.size() == 0) DrawObj();
	else DrawEnv();
}

void Object::DrawObj() {
	glBindBuffer(GL_ARRAY_BUFFER, m_pModel->m_vboId);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m_pModel->m_iboId);

	for (auto& tex2D: m_LTextures) {
		if (tex2D->isOn()) {
			glActiveTexture(GL_TEXTURE0 + tex2D->m_TexUnit);
			glBindTexture(GL_TEXTURE_2D, tex2D->m_TextureId);
			if (m_pShader->sampler2DLoc != -1) {
				glUniform1i(m_pShader->sampler2DLoc, tex2D->m_TexUnit);
			}
		}
	}

	int slot = 0;

	if (m_pShader->heightMapLoc != -1) {
		glUniform1i(m_pShader->heightMapLoc, slot++);
	}

	if (m_pShader->baseTexLoc != -1) {
		glUniform1i(m_pShader->baseTexLoc, slot++);
	}

	if (m_pShader->tex1Loc != -1) {
		glUniform1i(m_pShader->tex1Loc, slot++);
	}

	if (m_pShader->tex2Loc != -1) {
		glUniform1i(m_pShader->tex2Loc, slot++);
	}

	if (m_pShader->tex3Loc != -1) {
		glUniform1i(m_pShader->tex3Loc, slot);
	}

	if (m_pShader->mvpUniform != -1) {
		glUniformMatrix4fv(m_pShader->mvpUniform, 1, GL_FALSE, &m_TransformMtx.m[0][0]);
	}

	if (m_pShader->positionAttribute != -1) {
		glEnableVertexAttribArray(m_pShader->positionAttribute);
		glVertexAttribPointer(m_pShader->positionAttribute, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), 0);
	}

	if (m_pShader->texcoordAttribute != -1) {
		glEnableVertexAttribArray(m_pShader->texcoordAttribute);
		glVertexAttribPointer(m_pShader->texcoordAttribute, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)sizeof(Vector3));
	}

	glDrawElements(GL_TRIANGLES, m_pModel->m_nIndices, GL_UNSIGNED_INT, 0);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindTexture(GL_TEXTURE_2D, 0);
}

void Object::DrawEnv() {
	glBindBuffer(GL_ARRAY_BUFFER, m_pModel->m_vboId);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m_pModel->m_iboId);

	for (auto& texCube : m_LCubTexes) {
		if (texCube->isOn()) {
			glActiveTexture(GL_TEXTURE0 + texCube->m_TexUnit);
			glBindTexture(GL_TEXTURE_CUBE_MAP, texCube->m_TextureId);

			if (m_pShader->samplerCubeLoc != -1) {
				glUniform1i(m_pShader->samplerCubeLoc, texCube->m_TexUnit);
			}
		}
	}

	if (m_pShader->mvpUniform != -1) {
		glUniformMatrix4fv(m_pShader->mvpUniform, 1, GL_FALSE, &m_TransformMtx.m[0][0]);
	}

	if (m_pShader->positionAttribute != -1) {
		glEnableVertexAttribArray(m_pShader->positionAttribute);
		glVertexAttribPointer(m_pShader->positionAttribute, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), 0);
	}

	glDrawElements(GL_TRIANGLES, m_pModel->m_nIndices, GL_UNSIGNED_INT, 0);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindTexture(GL_TEXTURE_CUBE_MAP, 0);
}

void Object::SetModel(GLuint modelId) {
	m_pModel = resourceManager->GetModel(modelId);
}

void Object::SetTexture(GLuint textureId, Vector2 frameStart, Vector2 frameEnd, Vector2 size) {
	m_pTexture = resourceManager->GetTexture(textureId);
	m_pTexture->SetRenderArea(frameStart, frameEnd, size);
}

void Object::SetTextures(std::vector<int> texturesId) {
	for (const auto& id : texturesId) {
		m_LTextures.push_back(resourceManager->GetTexture(id));
	}
}

void Object::SetCubeTex(std::vector<int> cubeTexesId) {
	for (const auto& id : cubeTexesId) {
		m_LCubTexes.push_back(resourceManager->GetCubeTex(id));
	}
}

void Object::SetShader(GLuint shaderId) {
	m_pShader = resourceManager->GetShader(shaderId);
}

void Object::SetType(char* type) {
	strcpy(m_Type, type);
}

Vector3 Object::ToRadian(Vector3 angle) {
		angle *= (3.14 / 180);
		return angle;
}

void Object::SetScale(Vector3 vScale) { m_Scale = vScale; }

void Object::SetRotationAngle(Vector3 vRotation) {
	m_RotationalAngle = ToRadian(vRotation);
}

void Object::SetTranslation(Vector3 deltaMove) { m_Position += deltaMove; }

void Object::UpdateTransformMatrix(Matrix viewMatrix, Matrix projectionMatrix) {
	Matrix T = Matrix().SetTranslation(m_Position);

	Matrix Rz = Matrix().SetRotationZ(m_RotationalAngle.z);
	Matrix Rx = Matrix().SetRotationX(m_RotationalAngle.x);
	Matrix Ry = Matrix().SetRotationY(m_RotationalAngle.y);
	Matrix R = Rz * Rx * Ry;

	Matrix S = Matrix().SetScale(m_Scale);

	m_TransformMtx = S * R * T * viewMatrix * projectionMatrix;
}
#pragma once 

#include "Model.h"
#include "Texture.h"
#include "ResourceManager.h"
#include "Camera.h"
#include <vector>

class Object {
protected:
	GLuint					m_Id;
	Model*					m_pModel;
	Texture*				m_pTexture;

	std::vector<Texture*>	m_LTextures;
	std::vector<Texture*>	m_LCubTexes;

	Shaders*				m_pShader;
	ResourceManager*		resourceManager;

	Vector3					m_Target;
	Vector3					m_Scale;
	Vector3					m_RotationalAngle;

	Matrix					m_TransformMtx;

	void DrawObj();
	void DrawEnv();
	Vector3 ToRadian(Vector3 angle);

public:

	char* m_Type;
	Vector3					m_Position;
	Object(GLuint id);
	Object();
	~Object();

	int Init();
	virtual void Init(int spriteX, int spriteY, int spriteW, int spriteH, int textureW, int textureH, Vector2 origin){}

	void Draw();

	void SetModel(GLuint modelId);
	void SetTexture(GLuint textureId, Vector2 frameStart, Vector2 frameEnd, Vector2 size);
	void SetTextures(std::vector<int> texturesID);
	void SetCubeTex(std::vector<int> cubeTexesId);
	void SetShader(GLuint shaderId);
	void SetType(char* type);

	void SetScale(Vector3 vScale);

	void SetRotationAngle(Vector3 vRotation);
	void SetTranslation(Vector3 deltaMove);

	void UpdateTransformMatrix(Matrix viewMatrix, Matrix projectionMatrix);
};
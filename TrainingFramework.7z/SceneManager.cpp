#include "stdafx.h"
#include <cmath>
#include "SceneManager.h"

SceneManager* SceneManager::m_Instance = nullptr;

int SceneManager::Init(char* dataSource) {
	m_SourceData = dataSource;

	if (CreateObjectsAndCamera() != 0) return -1;
	return LoadObjects();
}

int SceneManager::CreateObjectsAndCamera() {
	FILE* file;
	if (!(file = fopen(m_SourceData, "r"))) return -1;

	//Set Objects
	int nObjs;
	fscanf_s(file, "#Objects: %d\n", &nObjs);

	for (int i = 0; i < nObjs; i++) {
		char type[20];
		Object* obj;
		fscanf(file, "ID %*d\nTYPE %s\n", type);

		if (strcmp(type, "SPRITE") == 0) {
			obj = new Sprite(i);
		}
		else {
			obj = new Object(i);
		}

		obj->SetType(type);
		
		Vector2 frameStart, frameEnd, sizeTexture;
		fscanf(
			file, "COORD %f %f %f %f %f %f\n", 
				&frameStart.x, &frameStart.y,
				&frameEnd.x, &frameEnd.y,
				&sizeTexture.x, &sizeTexture.y
		);

		int idTexture;
		fscanf(file, "TEXTURE %d\n", &idTexture);
		obj->SetTexture(idTexture, frameStart, frameEnd, sizeTexture);

		int idShader;
		fscanf(file, "SHADER %d\n", &idShader);
		obj->SetShader(idShader);

		Vector3 pos, rot, scale;
		fscanf_s(file, "POSITION %f, %f, %f\n", &pos.x, &pos.y, &pos.z);
		obj->SetTranslation(pos);

		fscanf_s(file, "ROTATION %f, %f, %f\n", &rot.x, &rot.y, &rot.z);
		obj->SetRotationAngle(rot);

		fscanf_s(file, "SCALE %f, %f, %f\n\n", &scale.x, &scale.y, &scale.z);
		obj->SetScale(scale);

		m_LObjs.push_back(obj);
		obj = nullptr;
	}

	//Set lights
	fscanf_s(file, "#LIGHTS\n");
	fscanf_s(file, "AmbientColor %*f, %*f, %*f\n");
	fscanf_s(file, "AmbientWeight %*f\n");

	int nLight;
	fscanf_s(file, "LightsCount: %d\n\n", &nLight);
	for (int i = 0; i < nLight; i++) {
		fscanf_s(file, "ID %*d\n");
		fscanf_s(file, "POS/DIR %*f, %*f, %*f\n");
		fscanf_s(file, "TYPE %*s\n");
		fscanf_s(file, "COLOR %*f, %*f, %*f\n");
		fscanf_s(file, "MOVING %*s\n");
		fscanf_s(file, "RADIUS %*f\n");
		fscanf_s(file, "SPEED %*f\n\n");
	}

	// Set Camera
	float nearP, farP, fov, speed;
	fscanf_s(file, "#CAMERA\n");
	fscanf_s(file, "NEAR %f\n", &nearP);
	fscanf_s(file, "FAR %f\n", &farP);
	fscanf_s(file, "FOV %f\n", &fov);
	fscanf_s(file, "SPEED %f\n", &speed);
	//SetCamera(fov, nearP, farP, speed);
	//SetCamera(-Globals::screenWidth/2, Globals::screenWidth/2, -Globals::screenHeight/2, -Globals::screenHeight/2, -1, 1, 3);
	SetCamera(-1, 1, -1, 1, -1, 1, 3);

	fclose(file);
	return 0;
}

int SceneManager::LoadObjects() {
	for (auto& pObj : m_LObjs) {
		if (pObj->Init()) return -1;
		pObj->UpdateTransformMatrix(camera.GetViewMatrix(), camera.GetProjectionMatrix());
	}

	return 0;
}

void SceneManager::Draw() {
	for (auto& pObj : m_LObjs) {
		pObj->Draw();
	}
}

void SceneManager::Update(unsigned char keyPressed, float deltaTime) {
	UpdateCamera(keyPressed, deltaTime);

	for (auto& pObj : m_LObjs) {
		pObj->UpdateTransformMatrix(camera.GetViewMatrix(), camera.GetProjectionMatrix());
	}
}

void SceneManager::Update(float x, float y, float deltaTime) {
	if (x > 0.9) camera.MoveAlongLocalX(deltaTime);
	if (x < -0.9) camera.MoveAlongLocalX(-deltaTime);
	if (y > 0.9) camera.MoveAlongLocalY(deltaTime);
	if (y < -0.9) camera.MoveAlongLocalY(-deltaTime);

	Vector4 worldMouse = Vector4(x, y, 0, 1) * camera.GetWorldMatrix();
	Vector3 target = Vector3(worldMouse.x, worldMouse.y, worldMouse.z) - m_LObjs[0]->m_Position;
	if (target.y) {

		printf("%f %f %f %f\n", x, y, x, y - 1);
		float tan = target.x / target.y;
		if (tan < 0) tan = -tan;
		float Angle = atan2(target.x, target.y);
		printf("%f\n", Angle);
		if (Angle > 0) {
			m_LObjs[0]->SetRotationAngle(Vector3(0, 0, -Angle * 180 / 3.14));
			m_LObjs[0]->UpdateTransformMatrix(camera.GetViewMatrix(), camera.GetProjectionMatrix());
		}
	}
}

void SceneManager::UpdateCamera(unsigned char keyPressed, float deltaTime) {
	if (keyPressed == 'A') m_LObjs[0]->SetTranslation(Vector3(-2 * deltaTime, 0, 0));
	if (keyPressed == 'D') m_LObjs[0]->SetTranslation(Vector3(2 * deltaTime, 0, 0));
	if (keyPressed == 'W') m_LObjs[0]->SetTranslation(Vector3(0, 2 * deltaTime, 0));
	if (keyPressed == 'S') m_LObjs[0]->SetTranslation(Vector3(0, -2 * deltaTime, 0));
	if (keyPressed == 'Z') camera.MoveAlongLocalZ(deltaTime);
	if (keyPressed == 'X') camera.MoveAlongLocalZ(-deltaTime);
	
	if (keyPressed == 'R') camera.RotateAroundWorldY(deltaTime);
	if (keyPressed == 'T') camera.RotateAroundWorldY(-deltaTime);
	if (keyPressed == 'G') camera.RotateAroundLocalX(deltaTime);
	if (keyPressed == 'H') camera.RotateAroundLocalX(-deltaTime);
	if (keyPressed == 'K') camera.RotateAroundLocalZ(deltaTime);
	if (keyPressed == 'J') camera.RotateAroundLocalZ(-deltaTime);
}

void SceneManager::UpdateCamera(float x, float y, float deltaTime) {
}

void SceneManager::SetCamera(float fov, float nearP, float farP, float speed) {
	camera.SetProjectionMatrix(fov, nearP, farP);
	camera.SetSpeed(speed);
}
void SceneManager::SetCamera(float left, float right, float bot, float top, float nearP, float farP, float speed) {
	camera.SetProjectionMatrix(left, right, bot, top, nearP, farP);
	camera.SetSpeed(speed);
}

void SceneManager::CleanUp() {
	for (auto& pObj : m_LObjs) {
		delete pObj;
	}
}
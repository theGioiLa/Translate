#pragma once
#include "../Utilities/utilities.h"
#include <vector>

class Shaders {
public:
	GLuint program, vertexShader, fragmentShader;
	GLuint m_Id;
	GLenum states;
	char* fileVS;
	char* fileFS;

	GLint positionAttribute, texcoordAttribute;
	GLint mvpUniform, sampler2DLoc, samplerCubeLoc;
	GLint heightMapLoc, baseTexLoc, tex1Loc, tex2Loc, tex3Loc;

	// Methods for Shaders Class
	Shaders() {}
	Shaders(GLuint id, GLenum enable_States = 0);
	~Shaders();

	int Init(char * fileVertexShader, char * fileFragmentShader);
	int Init();

	void FindUniformsAndAttributesLoc();

	void SetEnableState(GLenum enale_States);
};
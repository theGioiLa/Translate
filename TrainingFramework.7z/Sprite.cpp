#include "stdafx.h"
#include "Sprite.h"


Sprite::Sprite(int id) : Object(id)
{
}


Sprite::~Sprite()
{
}

void Sprite::Init(int x, int y, int w, int h, int textureW, int textureH, Vector2 origin) {
	m_pModel->Init(x, y, w, h, textureW, textureH, origin);
}

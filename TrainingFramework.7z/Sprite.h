#pragma once
#include "Object.h"
class Sprite :
	public Object
{

	Vector2					m_Origin;
public:
	Sprite(int id);
	~Sprite();

	void Init(int spriteX, int spriteY, int spriteW, int spriteH, int textureW, int textureH, Vector2 origin);
	void CreateModel(int x, int y, int w, int h);
};


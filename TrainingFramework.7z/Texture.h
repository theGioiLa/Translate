#pragma once
#include "../Utilities/utilities.h"

class Texture {
	GLuint		m_Id;
	GLenum		m_TilingMode;
	GLenum		m_TextureType;
	bool		isActive;

	void CreateTexture2D();
	void CreateTextureCubeMap();

public:
	GLuint		m_TextureId, m_TexUnit;
	Vector4		m_UVArea;
	Vector2		m_FrameStart, m_FrameEnd, m_Size;
	char*		m_Info;

	Texture() {}
	Texture(int id, GLenum textureType = GL_TEXTURE_2D, bool active = true);
	~Texture();

	void Init();
	void Draw();
	void CleanUp();

	void SetRenderArea(Vector2 frameStart, Vector2 frameEnd, Vector2 size);
	void SetTilingMode(GLenum tilingMode) { m_TilingMode = tilingMode; }
	void SetId(GLuint id) { m_Id = id; }
	void SetActicve(bool status) { isActive = status; }
	bool isOn() { return isActive; }
};